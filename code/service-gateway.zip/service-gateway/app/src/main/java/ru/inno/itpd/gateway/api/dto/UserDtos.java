package ru.inno.itpd.gateway.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public final class UserDtos {
    private UserDtos() {}

    public record BlockRequest(@NotBlank @Size(max = 500) String reason) {
    }

    public record BlockInfo(
            String reason,
            @JsonProperty("blocked_at") Instant blockedAt,
            @JsonProperty("blocked_by") String blockedBy,
            @JsonProperty("keycloak_disabled") boolean keycloakDisabled
    ) {
    }

    public record UserView(
            String id,
            String username,
            String email,
            @JsonInclude(JsonInclude.Include.NON_NULL) Boolean enabled,
            boolean blocked,
            @JsonInclude(JsonInclude.Include.NON_NULL) BlockInfo block,
            @JsonProperty("last_activity") Instant lastActivity
    ) {
    }
}
