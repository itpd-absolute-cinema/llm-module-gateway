package ru.inno.itpd.gateway.core.client.keycloak;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import ru.inno.itpd.gateway.config.properties.GatewayProperties;
import ru.inno.itpd.gateway.core.exception.GatewayException;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Keycloak Admin REST от имени service account шлюза (client credentials).
 * Нужные роли service account (клиент realm-management): view-users, manage-users.
 */
@Component
public class KeycloakAdminClient {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record KcUser(String id, String username, String email, String firstName, String lastName, Boolean enabled) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record TokenResponse(@JsonProperty("access_token") String accessToken,
                                 @JsonProperty("expires_in") long expiresIn) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record CountResponse(long count) {
    }

    private final GatewayProperties.KeycloakProperties props;
    private final RestClient http;

    private String token;
    private Instant tokenExpiry = Instant.EPOCH;

    public KeycloakAdminClient(GatewayProperties gatewayProps) {
        this.props = gatewayProps.keycloak();
        this.http = props.adminConfigured()
                ? RestClient.builder().baseUrl(trimSlash(props.baseUrl())).build()
                : null;
    }

    public boolean isConfigured() {
        return http != null;
    }

    public List<KcUser> search(String search, int first, int max) {
        Map<String, Object> vars = new HashMap<>();
        vars.put("realm", props.realm());
        vars.put("first", first);
        vars.put("max", max);
        boolean hasSearch = search != null && !search.isBlank();
        if (hasSearch) vars.put("search", search.trim());
        KcUser[] users = call(() -> http.get().uri(b -> {
            var u = b.path("/admin/realms/{realm}/users")
                    .queryParam("first", "{first}").queryParam("max", "{max}")
                    .queryParam("briefRepresentation", "true");
            if (hasSearch) u = u.queryParam("search", "{search}");
            return u.build(vars);
        }).headers(h -> h.setBearerAuth(token())).retrieve().body(KcUser[].class));
        return users == null ? List.of() : List.of(users);
    }

    public long count(String search) {
        Map<String, Object> vars = new HashMap<>();
        vars.put("realm", props.realm());
        boolean hasSearch = search != null && !search.isBlank();
        if (hasSearch) vars.put("search", search.trim());
        Long n = call(() -> http.get().uri(b -> {
            var u = b.path("/admin/realms/{realm}/users/count");
            if (hasSearch) u = u.queryParam("search", "{search}");
            return u.build(vars);
        }).headers(h -> h.setBearerAuth(token())).retrieve().body(Long.class));
        return n == null ? 0 : n;
    }

    public Optional<KcUser> find(String id) {
        try {
            KcUser user = call(() -> http.get().uri("/admin/realms/{realm}/users/{id}", props.realm(), id)
                    .headers(h -> h.setBearerAuth(token())).retrieve().body(KcUser.class));
            return Optional.ofNullable(user);
        } catch (GatewayException e) {
            if ("user_not_found".equals(e.code())) return Optional.empty();
            throw e;
        }
    }

    public void setEnabled(String id, boolean enabled) {
        call(() -> {
            http.put().uri("/admin/realms/{realm}/users/{id}", props.realm(), id)
                    .headers(h -> h.setBearerAuth(token()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of("enabled", enabled))
                    .retrieve().toBodilessEntity();
            return null;
        });
    }

    // ---- internals ----

    @FunctionalInterface
    private interface Call<T> {
        T run();
    }

    /** Выполняет вызов, один раз перевыпускает токен при 401, маппит ошибки в GatewayException. */
    private <T> T call(Call<T> call) {
        try {
            try {
                return call.run();
            } catch (RestClientResponseException e) {
                if (e.getStatusCode().value() != 401) throw e;
                invalidateToken();
                return call.run();
            }
        } catch (RestClientResponseException e) {
            if (e.getStatusCode().value() == 404) {
                throw new GatewayException(HttpStatus.NOT_FOUND, "user_not_found", "User not found in Keycloak");
            }
            throw mapStatus(e);
        } catch (ResourceAccessException e) {
            throw new GatewayException(HttpStatus.SERVICE_UNAVAILABLE, "identity_provider_unavailable",
                    "Could not connect to Keycloak");
        }
    }

    private static GatewayException mapStatus(RestClientResponseException e) {
        return new GatewayException(HttpStatus.BAD_GATEWAY, "identity_provider_error",
                "Keycloak responded with status " + e.getStatusCode().value());
    }

    private synchronized String token() {
        if (token != null && Instant.now().isBefore(tokenExpiry)) return token;
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "client_credentials");
        form.add("client_id", props.adminClientId());
        form.add("client_secret", props.adminClientSecret());
        try {
            TokenResponse r = http.post()
                    .uri("/realms/{realm}/protocol/openid-connect/token", props.realm())
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form)
                    .retrieve()
                    .body(TokenResponse.class);
            if (r == null || r.accessToken() == null) {
                throw new GatewayException(HttpStatus.BAD_GATEWAY, "identity_provider_error",
                        "Keycloak returned no access token for the gateway service account");
            }
            token = r.accessToken();
            tokenExpiry = Instant.now().plus(Duration.ofSeconds(Math.max(r.expiresIn() - 30, 5)));
            return token;
        } catch (RestClientResponseException e) {
            throw new GatewayException(HttpStatus.BAD_GATEWAY, "identity_provider_error",
                    "Keycloak rejected the gateway service account credentials (status "
                            + e.getStatusCode().value() + ")");
        }
    }

    private synchronized void invalidateToken() {
        token = null;
        tokenExpiry = Instant.EPOCH;
    }

    private static String trimSlash(String url) {
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }
}
